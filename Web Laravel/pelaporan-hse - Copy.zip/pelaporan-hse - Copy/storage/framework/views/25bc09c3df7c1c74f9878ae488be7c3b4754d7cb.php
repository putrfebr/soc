

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    
    

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data SOC</h6>
        </div>
        <div class="card-body">
            
            <div class="text-right px-3 py-3">
                <?php if(Auth::user()->roles == 'superadmin'): ?>
                <a href="<?php echo e(route('soc.create')); ?>" class="btn btn-outline-primary">
                    Input SOC
                </a>
                <?php endif; ?>

            </div>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Divisi</th>
                            <th>Tanggal & Waktu</th>
                            <th>Lokasi</th>
                            <th>Golden Rules</th>
                            <th>Unsafe Action</th>
                            <th>Safe Behaviour</th>
                            <th>Cuaca</th>
                            <th>Resiko</th>
                            <th>Tindakan</th>






                           
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $soc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                                
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($u->nama ?? ''); ?></td>
                            <td><?php echo e($u->divisi); ?></td>
                            <td><?php echo e($u->tanggal_waktu); ?></td>
                            <td><?php echo e($u->lokasi); ?></td>
                            <td><?php echo e($u->golden_rules == 1 ? 'Ya' : 'Tidak'); ?></td>
                            <td><?php echo e($u->unsafe_action); ?></td>
                            <td><?php echo e($u->safe_behaviour); ?></td>
                            <td><?php echo e(\App\Models\Soc::CUACA[$u->cuaca] ?? ''); ?></td>
                            <?php if($u->risk == 'Rendah'): ?>
                            <td><span class="badge badge-pill badge-info"><?php echo e($u->risk); ?></span></td>

                            <?php elseif($u->risk == 'Sedang'): ?>
                            <td><span class="badge badge-pill badge-warning"><?php echo e($u->risk); ?></span></td>
                            <?php elseif($u->risk == 'Tinggi'): ?>
                            <td><span class="badge badge-pill badge-danger"><?php echo e($u->risk); ?></span></td>

                            <?php endif; ?>
                            <td><?php echo e($u->action); ?></td>    
                            <td>
                                <a class="btn btn-info" href="<?php echo e(route('soc.show',$u)); ?>"><i class="fas fa-eye"></i></a>
                                <?php if(Auth::user()->roles == 'superadmin'): ?>
                                <a class="btn btn-warning" href="<?php echo e(route('soc.edit',$u->id)); ?>"><i class="fas fa-edit"></i></a>
                                <button href="<?php echo e(route('soc.destroy', $u->id)); ?>" id="delete" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                <?php endif; ?>
                                
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<form action="" method="post" id="deleteForm">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>
    <input type="submit" value="Hapus" style="display:none">
    </form>
    <?php $__env->startPush('scripts'); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>

    <script>
    $('button#delete').on('click', function(e){
      e.preventDefault();
    
      var href = $(this).attr('href');
    
      Swal.fire({
          title: 'Apakah Kamu yakin akan menghapus data ini?',
          text: "Data yang sudah dihapus tidak dapat dikembalikan!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya, Hapus!'
          }).then((result) => {
          if (result.value) {
              document.getElementById('deleteForm').action = href;
              document.getElementById('deleteForm').submit();
                  Swal.fire(
                  'Berhasi Dihapus!',
                  'Data Kamu Berhasil Dihapus.',
                  'success'
                  )
              }
          })
    
    
    })
   
    </script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\pelaporan-hse\resources\views/admin/soc/index.blade.php ENDPATH**/ ?>