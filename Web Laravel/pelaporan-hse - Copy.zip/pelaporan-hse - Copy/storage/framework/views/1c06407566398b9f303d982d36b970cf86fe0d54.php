<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Tracking Claim
                2023</span>
        </div>
    </div>
</footer><?php /**PATH F:\laragon\www\claim-tracking-app\resources\views/admin-layouts/partials/footer.blade.php ENDPATH**/ ?>