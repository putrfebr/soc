

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Home</h1>
        
    </div>

    <!-- Content Row -->
    <div class="row">

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-12 col-md-12">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-center">
                        <img src="<?php echo e(asset('ilustrasi/undraw_Welcoming.png')); ?>" class="img-fluid" alt="" width="350">
                        <h4 class="font-weight-bold">Hi <?php echo e(ucfirst(Auth::user()->name)); ?> Selamat Datang Di Sistem Claim Tracking </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Content Row -->

    

   
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\claim-tracking-app\resources\views/admin/home/index.blade.php ENDPATH**/ ?>