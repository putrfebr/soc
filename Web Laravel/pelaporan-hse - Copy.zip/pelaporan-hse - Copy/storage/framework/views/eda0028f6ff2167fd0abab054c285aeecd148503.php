<script src="<?php echo e(asset('template-admin/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('template-admin/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('template-admin/js/sb-admin-2.min.js')); ?>"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('template-admin/vendor/chart.js/Chart.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('template-admin/js/demo/chart-area-demo.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/js/demo/chart-pie-demo.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js" integrity="sha256-xNzN2a4ltkB44Mc/Jz3pT4iU1cmeR0FkXs4pru/JxaQ=" crossorigin="anonymous"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="
https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js
"></script>
<script src="<?php echo e(asset('template-admin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('template-admin/js/demo/datatables-demo.js')); ?>"></script>
<script>
    $(document).ready(function() {
    var interval = setInterval(function() {
        var momentNow = moment();
        let tanggal = momentNow.format("DD ")
        let bulan = momentNow.format("MMMM YYYY")
        let jam = momentNow.format("hh:mm:ss A")
        let realtimedate = `${tanggal} ${bulan} ${jam}`
        console.log(realtimedate)
        $("#realtime_date").html(`${realtimedate}`)
        // $("#date-part").html();
        // $("#day-part").html(
        // momentNow
        //     .format("dddd")
        //     .substring(0, 3)
        //     .toUpperCase()
        // );
        // $("#month-part").html();
        // $("#time-part").html();
    }, 100);
    });
</script>
<script>
    <?php if(session()-> has('success')): ?>
        swal({
            type: "success",
            icon: "success",
            title: "BERHASIL!",
            text: "<?php echo e(session('success')); ?>",
            timer: 3500,
            showConfirmButton: false,
            showCancelButton: false,
            buttons: false,
        });
        <?php elseif(session()-> has('error')): ?>
        swal({
            type: "error",
            icon: "error",
            title: "GAGAL!",
            text: "<?php echo e(session('error')); ?>",
            
            showConfirmButton: true,
            showCancelButton: false,
            buttons: true,
        });
        <?php endif; ?>
</script>

<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH F:\laragon\www\claim-tracking-app\resources\views/admin-layouts/partials/scripts.blade.php ENDPATH**/ ?>