

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo e($title); ?></h1>
        
    </div>

    <!-- Content Row -->
    <div class="row">

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-4 col-md-6 col-sm-12 mb-4">
            <div class="card border-left-secondary shadow h-100 py-2">
                
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-sm font-weight-bold text-secondary text-uppercase mb-1">
                                Formulir Klaim</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">
                                <div class="row">
                                    <div class="col">
                                        <p><span class="badge  badge-success">Selesai : <?php echo e($jumlah_form_klaim_proses); ?></span></p>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-4 col-md-6 col-sm-12 mb-4">
            <div class="card border-left-dark shadow h-100 py-2">
                
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-sm font-weight-bold text-secondary text-uppercase mb-1">
                                Mobile Service</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">
                                <div class="row">
                                    <div class="col">
                                        <p><span class="badge  badge-warning">Proses : <?php echo e($jumlah_mobile_service_proses); ?></span> </p>
                                    </div>
                                    <div class="col">
                                        <p><span class="badge  badge-success">Selesai : <?php echo e($jumlah_mobile_service_selesai); ?></span> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-sm-12 mb-4">
            <div class="card border-left-dark shadow h-100 py-2">
                
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-sm font-weight-bold text-secondary text-uppercase mb-1">
                                PJ Pelayanan</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">
                                <div class="row">
                                    <div class="col">
                                        <p><span class="badge  badge-warning">Proses : <?php echo e($jumlah_pj_pelayanan_proses); ?></span> </p>
                                    </div>
                                    <div class="col">
                                        <p><span class="badge  badge-success">Selesai : <?php echo e($jumlah_pj_pelayanan_selesai); ?></span> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-sm-12 mb-4">
            <div class="card border-left-dark shadow h-100 py-2">
                
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-sm font-weight-bold text-secondary text-uppercase mb-1">
                                Verifikasi Kepala Perwakilan</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">
                                <div class="row">
                                    <div class="col">
                                        <p><span class="badge  badge-warning">Proses : <?php echo e($jumlah_kepala_perwakilan_proses); ?></span> </p>
                                    </div>
                                    <div class="col">
                                        <p><span class="badge  badge-success">Selesai : <?php echo e($jumlah_kepala_perwakilan_selesai); ?></span> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-sm-12 mb-4">
            <div class="card border-left-dark shadow h-100 py-2">
                
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-sm font-weight-bold text-secondary text-uppercase mb-1">
                                Keuangan Dan Umum</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">
                                <div class="row">
                                    <div class="col">
                                        <p><span class="badge  badge-warning">Proses : <?php echo e($jumlah_keuangan_umum_proses); ?></span> </p>
                                    </div>
                                    <div class="col">
                                        <p><span class="badge  badge-success">Selesai : <?php echo e($jumlah_keuangan_umum_selesai); ?></span> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-md-6 col-sm-12 mb-4">
            <div class="card border-left-dark shadow h-100 py-2">
                
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-sm font-weight-bold text-secondary text-uppercase mb-1">
                                Pembayaran Klaim</div>
                            <div class="h4 mb-0 font-weight-bold text-gray-800">
                                <div class="row">
                                    <div class="col">
                                        <p><span class="badge  badge-warning">Proses : <?php echo e($jumlah_pembayaran_klaim_proses); ?></span> </p>
                                    </div>
                                    <div class="col">
                                        <p><span class="badge  badge-success">Selesai : <?php echo e($jumlah_pembayaran_klaim_selesai); ?></span> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        

        
    </div>

    <!-- Content Row -->

    

   
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\claim-tracking-app\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>