

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Tracking Claim</h1>

    <?php if($data->cek_resi??false): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Nomor Resi Tidak Dapat Ditemukan !</strong> Silahkan cek kembali nomor resi anda.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif; ?>
    <div class="row  justify-content-center align-items-center">
        <div class="col">
            <div class="card ">
                <div class="card-body">
                    <form action="<?php echo e(url("tracking-claim/create")); ?>">
                        <div class="form-row">
                          <div class="col-12">
                            <label for="">Nomor Resi</label>
                            <input type="text" name="code" class="form-control" placeholder="Nomor Resi" value="<?php echo e($data->code); ?>">
                          </div>
                          
                        </div>
                        <?php if($data->id??false): ?>
                        <div class="form-row mt-3">
                            <div class="col-12">
                              <label for="">Penerima Klaim</label>
                              <input type="text" name="" class="form-control" placeholder="" value="<?php echo e($data->regisKlaim->nama); ?>" disabled>
                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="form-row mt-4">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary mb-2 btn-block"><i class="fas fa-search"> Cari</i></button>
                              </div>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
    <?php if($data->id??false): ?>
    <div class="row mt-5">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <h5>Riwayat Resi</h5>
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>No Resi</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php $__currentLoopData = $data->history_resi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                        
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($u->resi->code); ?></td>
                                    <td><?php echo e($u->status); ?></td>
                                    <td><?php echo e(App\Libraries\MyLib::tgl_sql_to_indo($u->created_at->todatestring()) ?? ''); ?></td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\claim-tracking-app\resources\views/admin/tracking-claim/form.blade.php ENDPATH**/ ?>