<!DOCTYPE html>
<html lang="en">
@include('admin-layouts.partials.head')

<body >

    <div class="container">
        @yield('content')
    </div>
   @include('admin-layouts.partials.scripts')

</body>

</html>