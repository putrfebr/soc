@extends('errors::minimal')

@section('title', __('Forbidden'))
@section('code', '403')

@section('message')
Anda Tidak Mempunyai Hak Akses Ke Halaman ini.
@endsection
